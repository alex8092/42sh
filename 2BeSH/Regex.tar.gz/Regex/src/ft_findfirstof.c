#include "ft_regex.h"

int	ft_findfirstof(char *str, char *refs)
{
	int	index;

	index = 0;
	while (str[index])
	{
		if (ft_isinarray(str[index], refs))
			return (index);
		++index;
	}
	return (-1);
}
