#include "ft_regex.h"

int	ft_atoi(char *str)
{
	int	res;
	int	index;

	res = 0;
	index = 0;
	while (str[index] && (str[index] == ' ' || str[index] == '\t'))
		++index;
	while (str[index] && str[index] >= '0' && str[index] <= '9')
	{
		res *= 10;
		res += str[index] - '0';
		++index;
	}
	return (res);
}
