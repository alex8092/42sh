#include "ft_regex.h"

void	*ft_memalloc(int size)
{
	void	*ptr;
	int		index;

	ptr = malloc(size);
	if (ptr)
	{
		index = 0;
		while (index < size)
		{
			((char *)ptr)[index] = 0;
			++index;
		}
	}
	return (ptr);
}
