#include "ft_regex.h"

char	*ft_strndup(char *str, int n)
{
	int		index;
	char	*res;

	index = 0;
	res = (char *)ft_memalloc(sizeof(char) * (n + 1));
	if (res)
	{
		while (index < n)
		{
			res[index] = str[index];
			++index;
		}
	}
	return (res);
}
