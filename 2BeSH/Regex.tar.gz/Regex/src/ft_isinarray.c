#include "ft_regex.h"

t_bool	ft_isinarray(char c, char *ref)
{
	int	index;

	index = 0;
	while (ref[index])
	{
		if (ref[index] == c)
			return (true);
		++index;
	}
	return (false);
}
