#include "ft_regex.h"

int	main(void)
{
	t_regex	*reg;
	char	*str;
	size_t	len_match;

	reg = ft_regex("\".{0,}[^\\\"]\"");
	DEBUG(("%c\n", ((t_opbase *)reg)->c));
	str = ft_regmatch("bonjour tes  testERGWERtGWasttttltee mondet\"abc\"est", reg, &len_match);
	DEBUG(("res : %s\n", ft_strndup(str, len_match)));
	(void)str;
	return (0);
}
