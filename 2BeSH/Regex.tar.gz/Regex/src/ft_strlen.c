#include "ft_regex.h"

int	ft_strlen(char *str)
{
	int	index;

	index = 0;
	while (str[index])
		++index;
	return (index);
}
