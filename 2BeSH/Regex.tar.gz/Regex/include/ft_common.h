#ifndef FT_COMMON_H
# define FT_COMMON_H
# include <stdlib.h>

typedef enum e_bool	t_bool;

enum e_bool	{ true = 1, false = 0 };

void	*ft_memalloc(int size);
t_bool	ft_isinarray(char c, char *ref);
int		ft_findfirstof(char *str, char *ref);
char	*ft_strndup(char *str, int index);
int		ft_atoi(char *str);
int		ft_strlen(char *str);

#endif
